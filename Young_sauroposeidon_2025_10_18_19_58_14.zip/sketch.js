// === TRUE FULLSCREEN SHADER ===
// Works perfectly in p5.js Web Editor

let theShader, seedVal, palette, colorOffset = 0;
let waves = 9.0, freqBase = 3.0, swirlMul = 0.6, autoMotion = true;

const palettes = [
  ['#0b0f19','#1d2a44','#7dc4ff','#ffe6f7'],
  ['#0f0f12','#4a4e69','#9a8c98','#f2e9e4'],
  ['#0e0a1f','#4a00e0','#00dbde','#f8f8ff'],
  ['#081c15','#40916c','#95d5b2','#ffd166'],
  ['#1a0b2e','#a4508b','#ff99c8','#fff3b0'],
  ['#001219','#005f73','#0a9396','#ee9b00'],
  ['#240046','#7b2cbf','#e0aaff','#caf0f8']
];

const vert = `
attribute vec3 aPosition;
void main(){ gl_Position = vec4(aPosition, 1.0); }
`;

const frag = `precision mediump float;
uniform vec2 u_resolution;
uniform float u_time;
uniform vec2 u_mouse;
uniform float u_seed,u_waves,u_freqBase,u_swirlMul;
uniform vec3 u_c0,u_c1,u_c2,u_c3;

mat2 rot(float a){float c=cos(a),s=sin(a);return mat2(c,-s,s,c);}
vec3 mix4(vec3 c0,vec3 c1,vec3 c2,vec3 c3,float t){
  float e=smoothstep(0.0,1.0,t);
  vec3 m1=mix(c0,c1,clamp(e*1.8,0.0,1.0));
  vec3 m2=mix(c2,c3,clamp(e*1.2-0.2,0.0,1.0));
  return mix(m1,m2,smoothstep(0.2,0.8,e));
}
void main(){
  vec2 uv=(gl_FragCoord.xy-0.5*u_resolution)/min(u_resolution.x,u_resolution.y);
  float t=u_time*0.4;
  uv*=rot((u_mouse.x+u_mouse.y)*u_swirlMul+t*0.2);
  float r=length(uv),ang=atan(uv.y,uv.x);
  float sector=3.14159/u_waves; ang=mod(ang,2.0*sector); ang=abs(ang-sector);
  vec2 k=vec2(cos(ang),sin(ang))*r;
  float v=0.0;
  for(int i=0;i<10;i++){
    float fi=float(i);
    float a=(6.28318*fi/u_waves)+u_seed;
    vec2 d=vec2(cos(a),sin(a));
    float ph=dot(d,k*(u_freqBase+fi*0.27))+t*(0.7+0.05*fi)+u_seed*1.23;
    v+=cos(ph);
  }
  v/=10.0;
  v+=0.25*cos(r*18.0-t*2.0);
  float n=0.5+0.5*v;
  vec3 col=mix4(u_c0,u_c1,u_c2,u_c3,n);
  float vig=1.0-smoothstep(0.6,1.2,length(uv));
  col*=0.9+0.1*vig;
  gl_FragColor=vec4(col,1.0);
}
`;

function hexToRgb(h){const n=parseInt(h.replace('#',''),16);return[((n>>16)&255)/255,((n>>8)&255)/255,(n&255)/255];}
function currentPalette(){
  const p=palette.slice(),k=((colorOffset%4)+4)%4;
  return [p[k%4],p[(k+1)%4],p[(k+2)%4],p[(k+3)%4]];
}

function setup(){
  createCanvas(windowWidth, windowHeight, WEBGL);
  fullscreen(true); // this makes it actually fill your monitor
  noStroke();
  pixelDensity(1);
  seedVal=random(1000);
  palette=random(palettes).slice();
  theShader=createShader(vert,frag);
}

function windowResized(){
  resizeCanvas(windowWidth, windowHeight);
}

function setUniforms(){
  shader(theShader);
  theShader.setUniform('u_resolution',[width,height]);
  theShader.setUniform('u_time',autoMotion?millis()/1000.0:0.0);
  theShader.setUniform('u_mouse',[(mouseX/width)*2-1, -(mouseY/height)*2+1]);
  theShader.setUniform('u_seed',seedVal);
  theShader.setUniform('u_waves',waves);
  theShader.setUniform('u_freqBase',freqBase);
  theShader.setUniform('u_swirlMul',swirlMul);
  const p=currentPalette();
  theShader.setUniform('u_c0',hexToRgb(p[0]));
  theShader.setUniform('u_c1',hexToRgb(p[1]));
  theShader.setUniform('u_c2',hexToRgb(p[2]));
  theShader.setUniform('u_c3',hexToRgb(p[3]));
}

function draw(){
  setUniforms();
  plane(width, height); // this covers the whole screen in WEBGL
}

function mousePressed(){ seedVal=random(1000); }
function keyPressed(){
  if(key==='r'||key==='R')palette=random(palettes).slice();
  if(key==='c'||key==='C')colorOffset++;
  if(key==='+'||key==='=')waves=constrain(waves+1.0,3.0,36.0);
  if(key==='-')waves=constrain(waves-1.0,3.0,36.0);
  if(keyCode===UP_ARROW)freqBase=constrain(freqBase+0.3,1.0,12.0);
  if(keyCode===DOWN_ARROW)freqBase=constrain(freqBase-0.3,1.0,12.0);
  if(keyCode===RIGHT_ARROW)swirlMul=constrain(swirlMul+0.05,0.0,2.0);
  if(keyCode===LEFT_ARROW)swirlMul=constrain(swirlMul-0.05,0.0,2.0);
  if(key===' ')autoMotion=!autoMotion;
  if(key==='s'||key==='S'){saveCanvas('kaleido','png');}
}
